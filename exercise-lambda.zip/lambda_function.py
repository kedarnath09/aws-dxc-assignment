import json
import boto3

def lambda_handler(event, context):
    # TODO implement
    
    try:
        s3_bucket = 'sys-manager-params'
        ssm_userName = 'UserName'
        # TODO: write code...
        # Create boto3 client object for ssm
        ssm_client = boto3.client('ssm')
        
        # Retrieve UserName details
        response = ssm_client.get_parameter(Name=ssm_userName, WithDecryption=False)

        user = {}
        user[response['Parameter']['Name']] = response['Parameter']['Value']
        
        # Create boto3 client object for s3
        s3_client = boto3.client('s3')
        
        # Updating the user details in the bucket
        s3_client.put_object(Bucket=s3_bucket, Key='sample.json', Body=json.dumps(user))
        print('{} updated details in s3'.format(ssm_userName))
        return {
            'statusCode': 200,
            'body': 'example-lambda execution completed, {} details updated in S3'.format(ssm_userName)
        }
        
    except Exception as e:
        print('Error',str(e))
    
    
